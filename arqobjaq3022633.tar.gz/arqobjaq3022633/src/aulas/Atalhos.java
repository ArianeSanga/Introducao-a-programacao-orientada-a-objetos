
package aulas;


public class Atalhos {
        public static void main(String[] args) {
            
        
            System.out.println("main + tab : metodo public static void main(String[] args)");
            System.out.println("sout + tab : criar o System.out.println");
            System.out.println("ctrl + barra de espaço : listar as opçoẽs possíveis");
            System.out.println("ctrl + shift + seta para baixo : copia linha ou seleção copia código.");
            System.out.println("alt + scroll-mouse: zoom");
            System.out.println("shift + f6 : executa código");
            System.out.println("ctrl + shift + i : importa os pacotes java faltantes");
            System.out.println("ctrl + / : comenta e descomenta a linha ou seleção de código");
    }
}
