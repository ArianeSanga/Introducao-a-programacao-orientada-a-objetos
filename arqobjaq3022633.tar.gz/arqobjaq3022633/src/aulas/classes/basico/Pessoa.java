package aulas.classes.basico;

/**
 *
 * @author ariane
 */
//classe (categoria) TitleCase
public class Pessoa {

    //atributos da classe em camelCase
    public double altura;
    public char sexo;
    public double pesoIdeal;

    //o construtor padrão (sem parâmetros) aloca espaço de memória para as variaveis de instância com seus valores padrão(0 para numerico e falso para booleano e null para tipo referencia)
    //criado pela JVM
    Pessoa() {

    }

    Pessoa(double a, char s) {
        altura = a;
        sexo = s;
        calcularPesoIdeal();
    }

    //método da classe(operações) camelCase
    public void calcularPesoIdeal() {
        //variaveis locais nao dispoem de valor inicial
        double auxiliar;
        if (sexo == 'F' || sexo == 'f') {
            auxiliar = 62.1 * altura - 44.7;
        } else {
            auxiliar = 72.7 * altura - 58.0;
        }
       
        pesoIdeal = auxiliar;
    }
    
    
}
