package aulas.classes.basico;

/**
 *
 * @author ariane
 */
public class Main {

    public static void main(String[] args) {

        //criação de instâncias(objetos) da classe Pessoa
        //variavel do tipo referencia a ojetos da classe Pessoa
        Pessoa maria = new Pessoa();
        Pessoa joao = new Pessoa();

        //variaveis de instância(vareavies do objeto acessando por meio da variavel maria)
        maria.altura = 1.60;
        maria.sexo = 'f';
        maria.calcularPesoIdeal();

        //chamada do metodo da instancia do objeto da classe pessoa(objeto acessado por meio da variavel maria)
        System.out.println("peso ideal do objeto acessado por meio da variavel maria " + maria.pesoIdeal);

        joao.altura = 1.80;
        joao.sexo = 'm';
        joao.calcularPesoIdeal();
        System.out.println("peso ideal do objeto acessado por meio da variavel joão " + joao.pesoIdeal);

        //tipos primitivos vs tipo referencia
        int a, b, c;
        a = 2;
        b = 3;
        c = 2;

        ///tipos primitivos sao tratados por valor
        System.out.println("a == b" + (a == b));
        System.out.println("a == c" + (a == c));

        //tipo referencia sao tratados por referencia a memoria, e tudo o que nao for tipo primitivo é tipo referencia
        System.out.println(" maria == joao " + (maria == joao));

        
        //null é o valor padrao para variaveis do referencia
        Pessoa silva = null;//variavel tipo referencia 
        System.out.println("Silva=  " + silva);
        silva = maria; 
        

        System.out.println(" maria == silva " + (maria == silva));
        
        
        silva.altura = 1.60;
        maria.calcularPesoIdeal();

        //acesando o mesmo espaço de memoria
        System.out.println("peso ideal do objeto acessado por meio da variavel maria " + maria.pesoIdeal);
        System.out.println("peso ideal do objeto acessado por meio da variavel silva " + silva.pesoIdeal);

        Pessoa mateus = new Pessoa(1.71, 'm');
        System.out.println("peso ideal do objeto acessado por meio da variavel silva " + mateus.pesoIdeal);

        //quebrou a integridade do objeto
        mateus.altura = 2.00;
        System.out.println("peso ideal do objeto acessado por meio da variavel silva " + mateus.pesoIdeal);
        mateus.altura = -250.00;
        System.out.println("peso ideal do objeto acessado por meio da variavel silva " + mateus.pesoIdeal);
        
        
    }
}
