/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulas.classe.encapsulamento;

/**
 *
 * @author ariane
 */
public class Main {
    public static void main(String[] args) {
        
        Pessoa maria = new Pessoa(1.75,'f');
        
        System.out.println( "maria.obterPesoIdeal() " + maria.getPesoIdeal() );
        System.out.println( "maria.obterAltura() " + maria.getAltura() );
        
        double aux = maria.getAltura();
        aux = 2.5;        
        System.out.println( "maria.obterAltura() " + maria.getAltura() );
        
        maria.setAltura(1.61);
        System.out.println( "maria.obterAltura() " + maria.getAltura() );
        System.out.println( "maria.obterPesoIdeal() " + maria.getPesoIdeal() );
        
        // maria.alterarAltura(-2.55); // leva a erro
        // System.out.println( maria.obterAltura() );
      
    }
}
