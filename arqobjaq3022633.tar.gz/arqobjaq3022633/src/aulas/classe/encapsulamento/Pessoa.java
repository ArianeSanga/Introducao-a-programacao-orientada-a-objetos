package aulas.classe.encapsulamento;

/**
 *
 * @author ariane
 */
public class Pessoa {
    
    private double altura;
    private char sexo;
    private double pesoIdeal;
    
    public Pessoa(double a, char s){
        setSexo(s);
        setAltura(a);
    }

    //métodos obter são métodos de consulta
    public double getAltura(){
        return altura;
    }

    public char getSexo(){
        return sexo;
    }
   
    public double getPesoIdeal(){
        return pesoIdeal;
    }
    
    //métodos de modificação
    public void setAltura(double a){
        if(a > 0.0 && a < 2.50){
            altura = a;
            setPessoIdeal();
        }else{
            throw new IllegalArgumentException("altura > 0.0 && a < 2.50"); // envia uma mensagem de erro em java
        }

    }
    
    public void setSexo(char s){
        if(s == 'F' || s == 'f' || s == 'M' || s == 'm'){
        sexo = s;
        setPessoIdeal();
    }else{
            throw new IllegalArgumentException("sexo em (F,f,M,m)");
        }
    }
    
    private void setPessoIdeal(){
        
           if( sexo == 'f' || sexo == 'F' ) {
            pesoIdeal = 62.1 * altura - 44.7;
        } else {
            if( sexo == 'm' || sexo == 'M' ) {
                pesoIdeal = 72.7 * altura - 58.0;
            } else {
                throw new IllegalArgumentException("sexo em (f, F, m, M)");  
            }
        }
    }
   
}
    
