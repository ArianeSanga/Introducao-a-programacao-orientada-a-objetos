package arqobjaq3022633;


public class ARQOBJAQ3022633 {

   
    public static void main(String[] args) {
        System.out.println("Hello Wordl");
    }
    
}
